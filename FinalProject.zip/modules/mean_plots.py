
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

def risk_plots(df):
    df['risk_level'] = df['risk_level'].cat.reorder_categories(['low', 'mid', 'high'])
    
    num_rows = 3
    num_cols = 2
    fig, axes = plt.subplots(nrows=num_rows, ncols=num_cols, figsize=(12, 10))

    risk_levels = ['low', 'mid', 'high']
    axes = axes.flatten()

    plot_index = 0

    for i in df.columns:
        if i != 'risk_level' and plot_index < num_rows * num_cols:
            sns.scatterplot(data=df, x='risk_level', y=df[i], ax=axes[plot_index])
            means = [df[df['risk_level'] == j][i].mean() for j in risk_levels]
            axes[plot_index].plot(risk_levels, means, marker='o', color='red', label='mean', zorder=5)
            axes[plot_index].legend(loc='upper left')
            plot_index += 1

    plt.tight_layout()
    plt.show()
