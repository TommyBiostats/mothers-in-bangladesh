from statsmodels.stats.multicomp import pairwise_tukeyhsd


def bs_results(df):
    result = pairwise_tukeyhsd(endog = df['bs'], groups = df['risk_level'], alpha = 0.05)
    print('Results for Dependent Variable: Blood Sugar\n')
    print(result.summary())

def heart_rate_results(df):
    result = pairwise_tukeyhsd(endog = df['heart_rate'], groups = df['risk_level'], alpha = 0.05)
    print('Results for Dependent Variable: Heart Rate\n')
    print(result.summary())





