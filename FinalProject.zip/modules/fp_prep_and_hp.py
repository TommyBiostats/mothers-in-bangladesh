import os
import pandas as pd

def df_load(file_path=r"data\Mother_Health.csv"):

    df = pd.read_csv(file_path, low_memory=False)
    df = df.rename(columns={
        'Age': 'age',
        'SystolicBP': 'systolic_bp',
        'DiastolicBP': 'diastolic_bp',
        'BS': 'bs',
        'BodyTemp': 'body_temp',
        'HeartRate': 'heart_rate',
        'RiskLevel': 'risk_level'
    })
    order = ['risk_level'] + [col for col in df.columns if col != 'risk_level']
    df = df[order]
    df = df.drop_duplicates()
    df['risk_level'] = (
        df['risk_level']
        .astype('string')
        .replace({'low risk': 'low', 'high risk': 'high', 'mid risk': 'mid'})
        .astype('category')
    )
    df = df.drop(499).reset_index(drop=True)
    return df
