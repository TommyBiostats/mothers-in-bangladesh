from statsmodels.multivariate.manova import MANOVA

def manova_table(df):

    manova = MANOVA.from_formula('age + systolic_bp + diastolic_bp + bs + body_temp + heart_rate ~ risk_level', data=df)
    print(manova.mv_test())  
      
